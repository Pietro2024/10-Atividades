//1
let nome = 'gabriel fernandes';
console.log ("seu nome é",nome,"\n");

//2
let num1 = 124;
let num2 = 354;
let soma = num1 + num2;
console.log ("a soma de", num1);
console.log ("a soma de", num2);
console.log ("da o resultado de", soma,"\n");

//3
const frase1 = ("teremos a paz custo o que custar")
const frase2 = ("você e seu planeta vão virar poeira cosmica")
const semelhanca = ("ambas são frases de vilões")
console.log ("a primeira frase é",frase1)
console.log ("a segunda frase é", frase2)
console.log ("e a semelhança entre elas é", semelhanca,"\n")

//4
let numero1 = 20;
let numero2 = 40;
let numero3 = 60;

let soma2 = numero1 + numero2 + numero3;
const media = soma2 /3
console.log ("esse é o valor", numero1)
console.log ("esse é o valor", numero2)
console.log ("esse é o valor", numero3)
console.log ("essa é a media", media,"\n")


//5
let a = 5
let b = 555
a = b
b = a
console.log(a)
console.log(b,"\n")

//6
let largura = 4
let altura = 10
console.log (largura * altura,"\n")

//7
let celsius = 20
let fahrenheit = (celsius*9/5)+32
console.log (fahrenheit,"\n")

//8
let numerolegal = 40
console.log(numerolegal*numerolegal)

//9
let anoNascimento = 2008
let anoAtual = 2025

let resultado2 = 2025 - 2008
console.log("sua idade é",resultado2)

//10
let precoOriginal = 50
let precoDesconto = 30

let desconto = 50 - 30
console. log("o preço agr é", desconto)